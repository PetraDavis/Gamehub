# GHDRAGOC: part of GHDRAGOP. Keep it next to GHDRAGOP.
from ti_draw import*
from ti_system import*
import time
import random
DOWN=34
LEFT=24
RIGHT=26
OK=105
CLR=45
SECOND=21
BLACK=(0,0,0)
WHITE=(255,255,255)
GOLD=(230,180,40)
YELLOW=(240,220,60)
H=210
_C=[None]
def col(c):
 if c!=_C[0]:
  _C[0]=c
  set_color(c[0],c[1],c[2])
def fr(x,y,w,h):
 fill_rect(x-1,y-1,w+1,h+1)
COVER=[0]
def cls(c=BLACK):
 COVER[0]+=1
 col(c)
 fill_rect(-1,-1,321,211)
TY=6
def text(x,y,s,c=WHITE):
 col(c)
 draw_text(x,y+TY,s)
MSG=[0,0]
G_TEST=True
G_EVIL=0.12 if G_TEST else 0.004
G_T=20
G_LANDS=('Green Valley','Fire Mountain','Frost Peaks','Village')
G_GROUND=((50,130,60),(85,65,55),(215,225,240),(75,150,70))
G_TALL=((35,100,45),(120,90,60),(170,190,220),(75,150,70))
G_WATER=(40,90,190)
G_LAVA=(230,90,20)
G_ROCK=(110,105,115)
G_LEAF=(25,85,35)
G_BARK=(90,60,30)
G_CYAN=(60,230,230)
G_MAG=(230,60,220)
G_RARE=('Common','Uncommon','Rare','Epic','Legendary','Quantum')
def G_cl(b):
 return[tuple(b[i:i+3])for i in range(0,len(b),3)]
G_RCOL=G_cl(b'\xff\xff\xffx\xdcxZ\xa0\xff\xc8n\xf0\xe6\xb4(<\xe6\xe6')
G_ABC='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
G_PAINT=G_cl(b'\xdcF(<\x82\xe6F\xaaF\xf0\xbe(\xc8n\xf0\xf0x\x96((2\xf0\xf0\xf5')
G_PAL=G_cl(b'\x00\x00\x00\xff\xff\xff\xfa\xdc<\xf5\x8c\x1e\xdc(\x1exx}\xc8\xc8\xd2\x1eZ(Z\xbeP\xfa\x96\xc8nK(<\xe6\xe6\xe6<\xdc\xe6\xb4(\xaa\xd2\xfa')
G_PAL2=G_cl(b'\x82<\xbe\xbe\xc3\xcd(P\xc8\x1e\x1eF\xc8\x82\xff\xaa\x14\x1e')
G_PAL3=G_cl(b'F-\x14\xb4\x82\x14dix\xc8P\x96\x14\x8c\xa0\x14(x\xa0n<')
G_ARTB=b'\x02\x10\x1e\x19-\x08/\x19\x00\x19\x1b"\x04\x07\x00\x00\x00\x19\x19(\x05\x02\x00\x00\x00\x19)"\x04\x07\x00\x00\x00\x19\'(\x05\x02\x00\x00\x02\x11)\x1a9\x1f)#\x02\x116\x1b<\x1f6#\x01\x11\x1a\x1e\x05\x00\x00\x00\x01\x11)\x1e\x05\x00\x00\x00\x00\x11\x1a\x19\x0f\n\x00\x00\x02\x11\x12\x15\x1c\x1a\x16 \x00\x11\x11\x14\x07\n\x00\x00\x00\x11\n\x10\x0c\x08\x00\x00\x00\x11\x08\x13\x04\x05\x00\x00\x02\x10) 9\x1f)#\x00\x10\x08\x17\x0b\x02\x00\x00\x00\x18\x1a\x19\x0e\x02\x00\x00\x00\x18\x0b\x10\t\x01\x00\x00\x00\x0f\x18 \x13\x03\x00\x00\x00\x0f\x11\x18\x02\x06\x00\x00\x02\x0f\x12\x10\x19\n\x15\x12\x00\x10\x1d \x01\x03\x00\x00\x00\x10! \x01\x03\x00\x00\x00\x10% \x01\x03\x00\x00\x02\x10\x0f\x11\x14\n\x12\x11'
G_ARTL=b'\x01\x11\x1b"\x04\x00\x00\x00\x00\x11\x18"\x05\x07\x00\x00\x00\x11\x16(\x07\x02\x00\x00\x01\x11("\x04\x00\x00\x00\x00\x11%"\x05\x07\x00\x00\x00\x11#(\x07\x02\x00\x00\x00\x19\x0c\x10\x05\x01\x00\x00\x00\x01\x0c\x12\x03\x02\x00\x00\x00\x01\n\x17\x01\x01\x00\x00\x00\x01\x16)\x01\x01\x00\x00\x00\x01#)\x01\x01\x00\x00\x00\x00\r\x12\x02\x02\x00\x00\x00\x00\t\x14\x01\x01\x00\x00'
G_ARTW=b'\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x05\x1c\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x0f\x10\x03\x02\x0f\x10\x0f\x10\x15\x00\x00\x12\x00\x17'
G_BOSS=('Shadow Wyrm',110,12,0,(90,50,140),3)
G_EGGS={}
G_HUD=[None]
class G_Game:
 pass
def G_battle(*a):
 import GHDRAGOW
 r=GHDRAGOW.G_battle(*a)
 GHDRAGOW=None
 G__drop('GHDRAGOW')
 return r
def G_evil(*a):
 import GHDRAGOW
 r=GHDRAGOW.G_evil(*a)
 GHDRAGOW=None
 G__drop('GHDRAGOW')
 return r
def G_rest(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_rest(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_load(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_load(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_board(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_board(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_shop(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_shop(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_nest(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_nest(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_menu(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_menu(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_win(*a):
 import GHDRAGOX
 r=GHDRAGOX.G_win(*a)
 GHDRAGOX=None
 G__drop('GHDRAGOX')
 return r
def G_backpack(*a):
 import GHDRAGOY
 r=GHDRAGOY.G_backpack(*a)
 GHDRAGOY=None
 G__drop('GHDRAGOY')
 return r
def G_book(*a):
 import GHDRAGOY
 r=GHDRAGOY.G_book(*a)
 GHDRAGOY=None
 G__drop('GHDRAGOY')
 return r
def G_hatch(*a):
 import GHDRAGOY
 r=GHDRAGOY.G_hatch(*a)
 GHDRAGOY=None
 G__drop('GHDRAGOY')
 return r
def G__drop(m):
 import sys,gc
 try:
  del sys.modules[m]
 except Exception:
  pass
 gc.collect()
