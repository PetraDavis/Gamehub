# GHDRAGOP: the game part of GHDRAGON. Run GHDRAGON, not this.
from GHDRAGOB import*
GREY=(110,110,110)
def rbox(x,y,w,h,r,c,t=2,inner=BLACK,fill=True):
 edge(x,y,w,h,r,c,t)
 if fill:
  rect(x+t,y+t,w-2*t,h-2*t,inner)
def pause(s):
 time.sleep(s)
def message(lines,title=None):
 n=len(lines)+(1 if title else 0)
 h=n*18+30
 y=(H-h)//2
 rbox(20,y,280,h,8,WHITE)
 MSG[0],MSG[1]=(y,h)
 COVER[0]+=1
 yy=y+24
 if title:
  ctext(yy,title,GOLD)
  yy+=18
 for s in lines:
  ctext(yy,s)
  yy+=18
 while True:
  k=wkey()
  if k in(OK,CLR):
   return k
def choose(title,opts,sel=0):
 cls()
 ctext(24,title,GOLD)
 n=len(opts)
 for i in range(n):
  y=40+i*30
  c=GOLD if i==sel else WHITE
  rbox(60,y,200,24,8,c,2,BLACK,False)
  ctext(y+18,opts[i],c)
 while True:
  k=wkey()
  old=sel
  if k==UP:
   sel=(sel-1)%n
  elif k==DOWN:
   sel=(sel+1)%n
  elif k==OK:
   return sel
  elif k==CLR:
   return-1
  if sel==old:
   continue
  for i in(old,sel):
   y=40+i*30
   c=GOLD if i==sel else WHITE
   edge(60,y,200,24,8,c)
   ctext(y+18,opts[i],c)
G_NIGHT=(45,50,80)
G_ENAME=('fire','water','plant','star')
G_NAMES=('Blaze','Splash','Fern','Spark','Misty','Clover','Ziggy','Nova','Pebble','Rocket','Biscuit','Luna','Comet','Pip','Maple','Echo','Sunny','Bolt','Willow','Ash','Ripple','Twig','Ember','Taro')
G_PAINT=G_cl(b'\xdcF(<\x82\xe6F\xaaF\xf0\xbe(\xc8n\xf0\xf0x\x96((2\xf0\xf0\xf5')
G_FOES=((('Goblin',14,4,6,(110,160,60),3),('Bog Toad',16,4,7,(60,120,160),1)),(('Lava Imp',26,7,12,(240,120,30),0),('Rock Troll',32,7,14,(120,110,90),2)),(('Ice Wraith',34,9,16,(150,200,240),1),('Snow Yeti',42,9,18,(235,235,245),3)))
def G_egg_type(m):
 r=random.randint(0,999)
 rar=4 if r<4+2*m else 3 if r<30+10*m else 2 if r<110+25*m else 1 if r<330+40*m else 0
 return random.choice([i for i in range(20)if G_DT[i][2]==rar])
def G_paint(ops):
 ops.sort(key=lambda o:(o[0],o[1],o[2],o[3][1]if o[2]==0 else 0,o[3][0]))
 last=None
 for layer,c,kind,a in ops:
  if kind==0:
   if last and last[0]==(layer,c)and(last[2]==a[1])and(last[4]==a[3])and(last[1]+last[3]==a[0]):
    last[3]+=a[2]
    continue
   if last:
    rect(last[1],last[2],last[3],last[4],last[0][1])
   last=[(layer,c),a[0],a[1],a[2],a[3]]
   continue
  if last:
   rect(last[1],last[2],last[3],last[4],last[0][1])
   last=None
  if kind==1:
   circ(a[0],a[1],a[2],c)
  else:
   col(c)
   fill_poly(a[0],a[1])
 if last:
  rect(last[1],last[2],last[3],last[4],last[0][1])
def G_cells(g,todo,with_hero):
 mp=g.maps[g.m]
 ops=[]
 rows={}
 for x,y in todo:
  rows.setdefault(y,[]).append(x)
 for y in rows:
  xs=sorted(rows[y])
  i=0
  while i<len(xs):
   c=G_base(g.m,mp[y][xs[i]])
   j=i+1
   while j<len(xs)and xs[j]==xs[j-1]+1 and(G_base(g.m,mp[y][xs[j]])==c):
    j+=1
   ops.append((-1,c,0,(xs[i]*G_T,20+y*G_T,(j-i)*G_T,G_T)))
   i=j
 for x,y in todo:
  G_shapes(g.m,x,y,mp[y][x],ops)
 if with_hero:
  G_hero(g,ops)
 G_paint(ops)
def G_draw_map(g,after_msg=False):
 r0,r1=(0,9)
 if after_msg:
  r0=max(0,(MSG[0]-20)//G_T)
  r1=min(9,(MSG[0]+MSG[1]-20)//G_T+1)
 else:
  cls()
  G_HUD[0]=None
 G_cells(g,[(x,y)for y in range(r0,r1)for x in range(16)],r0<=g.y<r1)
 G_hud(g)
def G_save(g):
 s=[4,g.coins,g.own,g.book,g.dread]+(g.bag+[-1]*5)[:5]
 for d in g.pen:
  p=G_PAINT.index(d[6])+1 if d[6]in G_PAINT and d[6]!=G_DT[d[1]][3]else 0
  n=0
  for ch in d[0].upper():
   n=n*27+G_ABC.index(ch)+1
  s+=[n,d[1],d[2],d[5],p*200+d[7]*20+d[8]]
 try:
  from ti_system import store_list
  store_list('DRG',s)
 except Exception:
  pass
def G_quest_step(g,kind,what):
 q=g.quest
 if q is None or q[0]!=kind or(q[1]is not None and q[1]!=what):
  return
 q[3]+=1
 if q[3]>=q[2]:
  g.coins+=q[4]
  g.quest=None
  message(['You finished:',q[5],'+'+str(q[4])+' coins!'],'Quest done!')
def G_put_egg(g,t,near):
 mp=g.maps[g.m]
 for n in range(30):
  if near:
   x=g.x+random.randint(-1,1)
   y=g.y+random.randint(-1,1)
  else:
   x=random.randint(1,14)
   y=random.randint(1,7)
  if 0<=x<16 and 0<=y<9 and(mp[y][x]in '."')and((x,y)!=(g.x,g.y))and(near or abs(x-g.x)+abs(y-g.y)>3):
   mp[y][x]='E'
   G_EGGS[g.m,x,y]=t
   G_cells(g,[(x,y)],False)
   return True
 return False
def G_play():
 g=G_Game()
 g.maps=[[list(r)for r in mp]for mp in G_MAPS]
 G_EGGS.clear()
 for m in range(3):
  for y in range(9):
   for x in range(16):
    if G_MAPS[m][y][x]=='E':
     G_EGGS[m,x,y]=random.randint(0,6)if m==0 else G_egg_type(m)
 g.m,g.x,g.y=(0,3,2)
 g.hp=g.mhp=30
 g.pen=[]
 g.pick=None
 g.ride=None
 g.bag=[]
 g.warm=12
 g.coins=0
 g.own=0
 g.book=0
 g.quest=None
 g.seen=0
 g.spawn=100
 g.dread=0
 G_load(g)
 steps=0
 G_draw_map(g)
 if g.pen or g.bag:
  message(['Welcome back! You have',str(len(g.pen))+' dragons, '+str(g.coins)+' coins.'],'DRAGON TAMER')
 else:
  message(['The Shadow Wyrm scared','the dragons away. Find','eggs and raise a team!'],'DRAGON TAMER')
 G_draw_map(g,True)
 while True:
  k=wkey()
  if k==CLR:
   if message(['ENTER: save and quit','CLEAR: keep going'],'Quit?')==OK:
    G_rest(g)
    G_save(g)
    return
   G_draw_map(g,True)
   continue
  if k in(OK,SECOND):
   c=G_menu(g)
   if c:
    (G_backpack if c==1 else G_book)(g)
    G_draw_map(g)
   continue
  dx,dy={LEFT:(-1,0),RIGHT:(1,0),UP:(0,-1),DOWN:(0,1)}.get(k,(0,0))
  if dx==0 and dy==0:
   continue
  nx,ny=(g.x+dx,g.y+dy)
  if nx<0 or nx>15:
   m=(0 if nx>15 else-1)if g.m==3 else g.m+(1 if nx>15 else-1)
   if m<0 and g.m==0:
    m=3
   if 0<=m<=3:
    ch=g.maps[m][ny][15-g.x]
    if ch!='T'and(ch not in '~L^'or g.ride is not None):
     g.m=m
     if m<3:
      g.seen=max(g.seen,m)
     g.x=15-g.x
     G_draw_map(g)
   continue
  if ny<0 or ny>8:
   continue
  mp=g.maps[g.m]
  ch=mp[ny][nx]
  if ch in 'TW'or(ch in '~L^'and g.ride is None):
   continue
  if ch=='B':
   if G_battle(g,G_BOSS):
    G_win(g)
    return
   if g.hp<=0:
    return
   G_draw_map(g)
   continue
  if ch=='E'and(len(g.bag)>=5 or len(g.pen)+len(g.bag)>=10):
   G_draw_map(g)
   message(['Your backpack is full.']if len(g.bag)>=5 else['No room in your pen.','Let a dragon go first.'],'Egg')
   G_draw_map(g,True)
   continue
  ox,oy=(g.x,g.y)
  g.x,g.y=(nx,ny)
  if ch=='E':
   mp[ny][nx]='.'
   G_cells(g,[(ox,oy),(nx,ny)],True)
   e=G_EGGS.pop((g.m,nx,ny),0)
   if not g.bag:
    g.warm=12
   g.bag.append(e)
   G_hud(g)
   message(['You found an egg with',G_RARE[G_DT[e][2]]+" spots! It's in",'your backpack.'],'An egg!')
   G_draw_map(g,True)
   continue
  if ch=='Q':
   G_board(g)
   G_draw_map(g)
   continue
  if ch=='S':
   G_draw_map(g)
   if g.pick is None:
    message(['Hatch a dragon first!'],'Shop')
    G_draw_map(g,True)
   else:
    G_shop(g)
    G_draw_map(g)
   continue
  if ch=='H':
   while True:
    c=G_nest(g)
    if not c:
     break
    (G_backpack if c==1 else G_book)(g)
   G_draw_map(g)
   continue
  G_cells(g,[(ox,oy),(nx,ny)],True)
  if g.bag:
   g.warm-=1
   if g.warm<=0:
    G_hatch(g)
    continue
  g.spawn-=1
  if g.spawn<=0:
   g.spawn=random.randint(100,200)
   if g.m<3 and(not any((q[0]==g.m for q in G_EGGS))):
    G_put_egg(g,G_egg_type(g.m),False)
  G_hud(g)
  steps+=1
  if g.dread>0:
   g.dread-=1
  if g.m<3 and(g.dread==1 or(not g.dread and steps>3 and(random.random()<G_EVIL)))and(not g.book>>25&1)and any((G_DT[d[1]][2]>=3 for d in g.pen)):
   steps=0
   if not G_evil(g):
    return
   continue
  if ch=='"'and steps>3 and(random.random()<0.2):
   steps=0
   if not G_battle(g,random.choice(G_FOES[g.m])):
    return
   G_draw_map(g)
def G_back():
 G_play()
