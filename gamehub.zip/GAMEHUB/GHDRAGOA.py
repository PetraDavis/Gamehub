# GHDRAGOA: part of GHDRAGON, loaded only while it is needed.
from GHDRAGOP import*
G_SEC3="Tara~15~31~I'm Tara. Welcome/to Section 3, where/dreams end.#Just kidding!/...Mostly.~A Lumora! Okay,/your dreams might/NOT end here.|What is THAT?!/I'm the one whose/dreams are ending.|Stone and gold?/Section 3 just got/scary for ME.\n*Ugo~14~34~I don't need an/intro. People/know me.#...You don't?/Rude.~A Lumora? People/will know YOU now./Rude.|Nobody knows/what THAT is./Not even me.|Everybody will/talk about that/rock. Not me. Rude.\nWade~13~30~Wade here. I'm/a fisherman. So is/my Pearlhorn.#We're fishing for/a win today.~A Lumora! The/best catch I've/ever seen!|That came from/deeper than any/fish I've caught.|Can't fish a rock./Can't beat one/either, I bet.\nYuri~12~32~Yuri. I paint my/dragon's wins on/its scales.#I'm running out/of room.~I'd paint that/Lumora on my/dragon's scales!|I don't have paint/dark enough for/that thing.|Gold cracks! It/already looks/painted!\nDot~12~30~I'm Dot! I'm tiny,/but my dragon/isn't!#Size isn't/everything!~A Lumora! It's/even bigger than/my dragon!|That thing is/scary AND big!/Size IS everything!|A giant rock!/Okay, size is/kind of everything.\nIris~15~35~I'm Iris. My/dragon can see/every color.#And it sees you/losing.~My dragon sees/every color. It/sees stars now.|My dragon sees/every color. It/can't see THAT.|Gold, silver and/grey. My dragon/loves those colors.\nKai~14~33~I'm Kai. I surf/on my dragon's/back. Gnarly!#Let's ride, dude!~A Lumora!/Totally gnarly,/dude!|Dude... that is/NOT gnarly. That/is creepy, dude.|Dude, you can't/surf on a rock!/...Can you?\nGwen~13~31~I'm Gwen, the/dragon doctor! I/fix hurt dragons.#Your dragon will/need me later.~A Lumora! I'd/love to check/its heartbeat!|I don't know how/to fix whatever/THAT is.|A stone dragon!/My bandages won't/stick to that.\nPax~15~32~Hi! I'm Pax. I love/peace and making/friends!#...Right after I/beat you, though.~A Lumora! Let's/be friends! After/I beat you.|I want to make/friends with that./...From far away.|Rocks are good/friends. They never/leave. Or move.\nThea~14~36~Thea. I collect/badges. I have 49.#You'll be/number 50.~A Lumora! You/should get a badge/just for that!|There's no badge/for whatever that/is. I'd know.|A rock dragon/badge! That'd be/number 50!\nXena~16~38~I'm Xena, warrior/tamer! My dragon/and I are ONE!#Feel our/POWER!~A Lumora! Our/POWER meets its/LIGHT!|Even a warrior/feels fear. That/thing... is fear.|A warrior made/of stone! Finally,/a real fight!\nBea~16~33~Bea! Like a bee!/Buzz buzz!#...And yes, I/sting. Hard.~Buzz! A Lumora!/Even bees like/stars!|Bees run from/smoke. I'm running/from THAT.|Stinging a rock/hurts the bee./I learned that.\nEzra~16~37~Ezra. I've studied/your fights. All/of them.#I have notes./Lots of notes.~A Lumora. Note:/change strategy./Big time.|My notes say/nothing about/that. NOTHING.|Note: stone./Note: gold./Note: I'm worried.\n*Flint~16~39~Spark. Fire./Done.#That's how fast/this goes.~Lumora. Bright./Nice.|Dark. Too dark./Nope.|Stone. Fire won't/help. Ugh.\nOrin~16~36~Orin. I forge/swords AND tame/dragons.#Both are hot./Both burn.~A Lumora! I'd/forge a sword/from its starlight.|I've worked dark/forges. Never seen/THAT kind of dark.|Gold veins in/stone! Best metal/I've ever seen.\nAbel~17~34~I'm Abel. I came/all the way from/across the sea.#I'm not going/home a loser.~Across the sea/they only TALK/about Lumoras!|Nobody across the/sea has seen/anything like that.|I crossed the sea/to see THAT?/Worth the trip.\n*Jax~17~40~I used to be a/pirate. Now I'm/something worse.#A pirate with/a dragon.~A Lumora! My/pirate heart says/steal it. I won't.|Even pirates know/when to sail away./Like now.|Gold in the/rock! That's/treasure, matey!\nRue~17~38~I'm Rue. You'll rue/the day you met me.#Get it? Rue?/...Nobody laughs.~You'll rue the/day... wait, a/Lumora? I rue it.|I rue the day/I saw that./Get it? ...Brr.|Rock beats me./Rue... ME./Oh no.\n*Vic~17~41~My name? Let's just/say it's short/for victory.#My parents knew.~A Lumora? Victory/just got harder.|Short for victory./Not short for/'fight THAT'.|That rock is/short for/'I lose'.\nLark~18~35~Lark! I sing to my/dragon before every/fight. La la la!#This one's a sad/song. For you.~A Lumora! I'll/write a happy/song about it!|La la... la./I forgot the words./What IS that?|A rock song! I/finally get to/sing one!\nCyrus~18~42~Cyrus. My family/has tamed dragons/for 300 years.#You're just/a beginner.~A Lumora. My/family has met/only two.|300 years of/tamers. Not one/saw THAT.|My family never/tamed a rock./Until now?\n*Hugo~18~44~The biggest tamer/in the arena./Literally.#I'm 7 feet tall./Scared yet?~A Lumora! For/once I feel/small. Nice.|7 feet tall,/and I'm hiding./What IS that?|That rock is/bigger than me!/Feels weird.\n*Nell~18~40~...#I don't smile./...Okay, maybe/when I win.~...#...I'm smiling./Don't tell anyone.|...#...I'm not smiling./At all.|...#...Okay. That's/cool. Fine.\nUna~18~43~I'm Una. Number/one. Always.#Literally. Una/means one.~A Lumora! Number/one dragon. Ugh,/I'm number two.|That's not number/one. That's number/zero. Scary.|One rock dragon./Only one./Like me.\nVera~18~45~I'm Vera. I've won/every tournament/for 10 years.#Except one. We/don't talk about it.~A Lumora. In 10/years I've seen/only two.|10 years of/tournaments. Never/seen THAT.|Remember the one/I lost? Not to/that. Phew.\nZoe~17~39~I'm Zoe, and this/is my Abyssar./Pretty, right?#She's even prettier/when she wins.~A Lumora! Okay,/that's prettier/than my Abyssar.|Pretty? No./Scary. Super/scary.|Gold and stone!/Pretty AND tough./I'm jealous.\nMilo~18~41~I'm Milo. My/Rootwyrm was a gift/from my grandpa.#He never lost./Neither will I.~Grandpa told me/about Lumoras./He'd love this.|Grandpa never/told me about/anything like that.|Grandpa liked/rocks. He'd have/LOVED that.\nSkye~17~42~I'm Skye. My dragon/has never touched/the ground.#You won't either/after this hit.~A Lumora! Its/wings look like/the night sky.|That came from/somewhere darker/than the sky.|A rock that/flies? Now I've/seen everything.\nWren~18~44~I'm Wren, the last/one before the/Grandmaster.#Nobody has passed/me in two years.~A Lumora. Maybe/you WILL get past/me.|Two years nobody/passed me. That/thing might.|A stone wall,/like me. Who/blinks first?\nGrandmaster Zora~19~46~So. You're the one/everyone whispers/about.#I am Grandmaster/Zora. Nobody has/ever beaten me.~Another Lumora.#Two stars in one/arena. Only one/will shine.|In all my years/I have never seen/such a creature.|Stone and gold./I thought I'd seen/it all. I was wrong."
G_SEC2="Gus~7~19~GUS! I'M GUS! I/YELL A LOT!#SORRY! NOT SORRY!/LET'S FIGHT!~A LUMORA?! THAT'S/SO COOL I'M/YELLING MORE!|WHAT IS THAT?!/IT'S SO DARK! I/CAN'T STOP YELLING!|A ROCK DRAGON?!/WITH GOLD?! THAT'S/LOUD-LEVEL COOL!\nAsh~8~18~I'm Ash. Like the/dragon. Like what/fire leaves behind.#Guess which one/you'll be soon.~Stars on its wings./Fire could never/burn that bright.|That thing is/darker than ash./I don't like it.|Stone doesn't/burn. That's.../a problem for me.\n*Cole~9~21~...#...My Glacius/does the talking.~...!#...Nice Lumora.|......#...What IS that?|...#...Whoa.\nBree~10~19~Bree here! I talk/fast, I fight fast,/I win fast!#Ready? Set? GO!~LumoraLumoraLumora!/I can't talk fast/enough for this!|Wait-what-is-that?/I've never seen/that! Not ever!|Is-that-a-ROCK?/That-MOVES?! Okay,/I'm-slowing-down.\nKip~10~18~Hi, I'm Kip! I'm/the youngest in/Section 2!#Don't go easy on/me. I won't!~Is that a real/Lumora?! Can I/touch it? Please?|Whoa... it's like/a shadow with/eyes. I'm scared!|A dragon made of/rocks?! I want to be/you when I grow up!\nIvo~11~22~Ivo's the name./Thorns are my/game.#Touch my dragon/and you'll regret it.~Even my thorns/bow to a Lumora./Respect.|Thorns can't hurt/a shadow. What/is that thing?!|Thorns on stone/just snap. Great./Just great.\nOtto~11~20~I'm Otto. I grow/the best turnips/in the land.#Also, I crush/tamers. Hobby.~A Lumora! Worth/more than every/turnip I've grown.|That's no turnip./That's no dragon/I know, either!|I hate rocks in/my field. But THAT/rock I'd keep!\nPia~9~18~Pia! I've never/won a match.#But today feels/different!~A Lumora?! Okay,/today does NOT/feel different now.|What is THAT?!/Never mind. I've/lost already.|A walking boulder!/Maybe I'll win/next year...\n*Quinn~8~23~Fastest tamer/alive. Don't/blink.#You blinked. That's/one point for me.~A Lumora. My fast/eyes saw that/one coming.|I blinked. And/that thing was/still staring.|Fast beats rock?/...Usually. Not/that rock.\n*Max~7~24~Maximum power./Maximum speed.#Minimum mercy.~Maximum Lumora./Maximum jealous.|Maximum creepy./Minimum idea what/that thing is.|Maximum rock./Maximum gold./Maximum unfair.\nEli~12~21~Eli. I wake up at/dawn every day/to train.#What time did YOU/wake up? Thought so.~A Lumora! Like/the sky right/before dawn.|That thing is/darker than the/night before dawn.|Gold cracks, like/the sun rising/through stone.\nLuna~12~25~I'm Luna. I only/fight at night...#...but I'll make an/exception for you.~Stars on its/wings... my kind/of dragon.|I love the night./But THAT is/darker than night.|It shines gold/in the dark./I like it.\nFaye~13~20~I'm Faye, and this/is Princess Pearl./Say hi, Pearl!#She says you're/going down.~Princess Pearl,/look! A Lumora!/Be polite!|Princess Pearl is/hiding behind me./Me too, honestly.|Pearl says rocks/aren't pretty. She's/WRONG this time.\nHana~14~24~I'm Hana. I've read/every dragon book/in the library.#I already know/your weak spot.~A Lumora! It's on/page 1 of every/dragon book I own!|That's in NO book/I've read. And I've/read them all!|Not in any book!/I'm writing my/own book now.\nJade~14~22~I'm Jade, and yes,/my dragon is a/Jadewyrm.#We match. It's/a whole thing.~A Lumora! We/don't match, but/I'll allow it.|That one matches/nothing. Not even/the night.|Gold and stone./That matches/everything.\nDina~15~21~I'm Dina! I braid/flowers into my/dragon's tail.#Pretty AND deadly!~A Lumora! I'd/braid starflowers/into its tail!|No flower would/grow near that./Brr.|I'd put flowers/in its cracks!/So pretty!\n*Rex~13~26~Names are for/winners. Call me/'The End'.#...Okay, that one/sounded cooler/in my head.~A Lumora. Fine./'The End' is still/coming. For you.|...'The End'/doesn't want to/fight that thing.|A rock dragon?!/...Call me/'The Beginning'.\n*Nora~15~25~I found my dragon/in a cave nobody/came out of.#Want to know/why? Heh.~Even my secret/cave had no/Lumora in it.|I've been in dark/caves. Nothing/THAT dark.|It looks like it/crawled out of MY/cave. Hmm.\nSage~14~27~I am Sage. I have/meditated for/three days.#I already know how/this ends.~A Lumora. My/meditation did/not foresee that.|I meditated/three days. I did/not see THAT.|Stone is calm./Stone is patient./Stone is... winning.\nSir Cedric~16~28~I am Sir Cedric,/keeper of the/second gate.#Nineteen tamers fell/before me. You will/be the twentieth.~A Lumora at my/gate. A worthy/challenger at last.|In all my years/at this gate, never/one like THAT.|A knight of stone/and gold! Even my/gate bows to it."
G_TAMERS="Timmy~0~2~Hi! I'm Timmy!/This is my first/tournament!#My Pyrrak is gonna/toast you!/...Probably.~Is that a LUMORA?!/Those are, like,/super legendary!|WHAT is THAT?!/It looks like space!/Is it even real?!|A ROCK DRAGON?!/With GOLD cracks?!/Best rock EVER!~WHOA! It's SILVER!/Is that normal?!/That's so cool!|It's GOLD! Like a/treasure! Can my/Pyrrak be gold too?|It GLOWS! Mom has/to see this! Wait,/do I still fight it?|PURPLE AND BLUE?!/Best. Day. EVER!/I'm telling everyone!\nLulu~4~4~I'm Lulu. Aww, is/that your dragon?/It's so tiny!~A Lumora?! Okay,/that is NOT tiny./That's amazing.|What... IS that?/I'm scared. And/also jealous.|Is it... a statue?/Wait, it MOVED!/Ahh!\nRocco~6~5~Name's Rocco.#Rocks beat everything./That's science.~|That thing isn't/rock. I don't trust/it. At all.|A dragon made of/ROCK! I TOLD you/rocks are the best!\nMira~2~7~I'm Mira. I've never/lost. Not once. Ever./Don't ruin it.~A Lumora... I've/only seen one in/a painting.|I've never seen a/dragon like that./What IS it?|Gold cracks and/crystals? Is that/even a dragon?\nDex~1~8~Dex. Remember it,/because you'll be/crying it later.~||\nCaptain Vex~3~11~Captain Vex! I've/beaten 100 tamers./You're number 101.~A Lumora! Stars on/its wings, like a/sailor's night sky!|Blimey! What beast/is THAT? It's like/the night itself!|That's no dragon,/it's a walking/treasure chest! Arr!\nDuchess Ivy~5~13~I am Duchess Ivy.#Kneel before my/Lichenwing, peasant!~A Lumora! Even I/don't own one./How dare you.|That dragon... it's/darker than my/castle dungeon!|Gold AND crystals!/The fanciest dragon/in all the land!\nGrim~8~14~...I'm Grim.#...Your dragon looks/tired already.~|......!#...Finally. A dragon/as dark as me.|...A stone dragon.#...It looks older/than the mountains.\nSheen~23~15~A hooded tamer with/yellow eyes steps up.#Name's Sheen. NOT/Shen. Never heard of/him. Heh.#Behold my super rare/GOLDEN DRAGON!/Shiny, huh? Heh heh.~|Ooh, nice dragon./Wanna sell it? I'll/give you 20 coins.|Those crystals look/valuable. Wanna/trade? Heh heh.\nAurora~10~16~I'm Aurora, the/champion. So you/made it this far.#Impressive. Now watch/me end it.~A Lumora! I've/always wanted one./Lucky you.|I've never seen/that dragon. Not/even in books.|A dragon of stone?/I didn't know they/existed. Amazing."
def G_tamer(s,i,k,g=0):
 if g:
  w,N=(i,k)
  c=(0,15,30,50,75,100,130,165,200,250,300)[w]if not s else(25,30)[s-1]*w
  m=['You won '+str(w)+' of '+str(N)+' matches.','+'+str(c)+' coins!']
  if w>N*2//3:
   g.glim+=s+1
   m.append('And '+str(s+1)+' Glimmer Stone'+'s!'[s<1:])
  if w==N:
   if s<2:
    m=['SECTION '+str(s+1)+' WON!','+'+str(c)+' coins!','Section '+str(s+2)+' is open!'if not g.book>>37+s&1 else 'Glimmer Stones too!']
    g.book|=1<<37+s
    if not g.book>>39+s&1:
     if len(g.bag)<5:
      g.book|=1<<39+s
      g.bag.append(random.choice([i for i in range(20)if G_DT[i][2]==s+2]))
      m.append(('And a Rare egg!','And an Epic egg!')[s])
     else:
      m.append('(No room for the egg!)')
   elif not g.book>>35&1 and len(g.bag)<5 and(G_kids(g)+4<=40):
    g.book|=1<<35
    g.bag.append(24)
    m=['GRAND CHAMPION!','+'+str(c)+' coins and a','Champion egg!']
   else:
    m=['GRAND CHAMPION!','+'+str(c)+' coins and','3 Glimmer Stones!'if g.book>>35&1 else '(no room for the egg!)']
  g.coins+=c
  message(m,'Arena')
  return
 T=(G_TAMERS,G_SEC2,G_SEC3)[s].split('\n')[i].split('~')
 return(T[0],int(T[1]),int(T[2]),T[3],T[4].split('|')[k-19]if 18<k<22 else '',T[5]if len(T)>5 else 0)
def G_arena(g,*a):
 import gc
 d=g.pick
 if d is None:
  message(['Come back when you','have a grown dragon!'],'Arena')
  return
 op=(1,g.book>>37&1 or g.book>>35&1,g.book>>38&1)
 s=choose('THE ARENA',['Section '+str(i+1)+(': '+str(10*i+10)+' tamers'if op[i]else ': locked')for i in range(3)]+['Leave'])
 if not 0<=s<3:
  return
 if not op[s]:
  message(['Win Section '+str(s),'first!'],'Arena')
  return
 fee=min(500,25+25*g.ar)
 if choose('SECTION '+str(s+1),['Enter: '+str(fee)+'c','Leave'])!=0:
  return
 if g.coins<fee:
  message(['The entry fee is',str(fee)+' coins. Come','back with more!'],'Arena')
  return
 g.coins-=fee
 g.ar+=1
 w=0
 N=10*s+10
 for i in range(N):
  n,k,lv,say,e,sh=G_tamer(s,i,d[1])
  n='???'if n[0]=='*'else n
  cls(G_NIGHT)
  ctext(24,'ROUND '+str(w+1)+' OF '+str(N),GOLD)
  for p in say.split('#'):
   message(p.split('/'),n)
  q=d[9]&7
  for p in e.split('#')if e else():
   message(p.split('/'),n)
  if sh and q:
   message(sh.split('|')[q-1].split('/'),n)
  if e and q and(not w):
   message((['People in the crowd','point at your dragon.'],['The crowd starts','whispering...'],['The whole crowd','goes silent...'],['The crowd ROARS!','Everyone jumps up','to see your dragon!'])[q-1],'Arena')
  d[3]=d[4]
  g.ride=d
  t=G_DT[k]
  r=4 if k==23 else t[2]
  f=(t[0],20+6*r+6*lv,4+lv+2*r,3*lv,t[3],t[1],k)
  if k==23:
   f=('Gold Dragon',)+f[1:4]+(GOLD,)+f[5:]+(2,)
  elif random.random()<0.17:
   f+=(random.randint(1,s+2),)
  gc.collect()
  if not G_battle(g,f,0,1):
   break
  w+=1
 d[3]=d[4]
 G_tamer(s,w,N,g)
